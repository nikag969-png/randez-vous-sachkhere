# Rendez-vous რანდე-ვუ

Astro 5 website for Rendez-vous in Sachkhere, Georgia.

Confirmed business information used:
- Phone: +995 599 32 33 90
- Hours: every day, 10:00–22:00
- Google rating: 4.7/5, 52 reviews at the time of preparation
- Coordinates: 42.33521, 43.40657
- Google Maps: https://maps.app.goo.gl/Xt1WAp3Y1sTgkmPM6

## Start

npm install
npm run dev

## Build

npm run build
npm run preview

## Notes

Menu prices are intentionally not invented. Update src/components/MenuCarousel.tsx with the exact live menu before launch if you want prices displayed.
