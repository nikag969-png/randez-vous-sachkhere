import { defineCollection, z } from 'astro:content';

const menuCollection = defineCollection({
  type: 'data',
  schema: z.object({
    title: z.string(),
    description: z.string(),
    price: z.string().optional(),
    category: z.enum(['breakfast', 'lunch', 'dinner', 'drinks', 'vegan', 'bakery', 'dessert']),
    image: z.string().optional(),
    isPopular: z.boolean().default(false)
  })
});

export const collections = {
  menu: menuCollection
};
