import * as React from 'react';
import { motion } from 'framer-motion';

const menuItems = [
  {
    id: 1,
    title: 'Khachapuri',
    description: 'A Georgian favorite, freshly prepared and served warm.',
    image: 'https://images.unsplash.com/photo-1593560708920-61dd98c8c8a8?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 2,
    title: 'Lobiani',
    description: 'A comforting Georgian bean-filled pastry.',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 3,
    title: 'Cakes & Pastries',
    description: 'Sweet treats and pastries for coffee, dessert or takeaway.',
    image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 4,
    title: 'Coffee & Cappuccino',
    description: 'Coffee classics to pair with something fresh from the bakery.',
    image: 'https://images.unsplash.com/photo-1497935586351-b67a49e012bf?auto=format&fit=crop&q=80&w=800'
  }
];

export default function MenuCarousel() {
  const carouselRef = React.useRef<HTMLDivElement>(null);
  const [width, setWidth] = React.useState(0);

  React.useEffect(() => {
    const updateWidth = () => {
      if (carouselRef.current) {
        setWidth(Math.max(0, carouselRef.current.scrollWidth - carouselRef.current.offsetWidth));
      }
    };

    updateWidth();
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, []);

  return (
    <div className="w-full overflow-hidden py-12" ref={carouselRef}>
      <motion.div
        drag="x"
        dragConstraints={{ right: 0, left: -width }}
        whileTap={{ cursor: 'grabbing' }}
        className="flex cursor-grab gap-6 px-6 md:px-12"
      >
        {menuItems.map((item) => (
          <motion.article
            key={item.id}
            className="min-w-[300px] flex-shrink-0 overflow-hidden rounded-2xl border border-[var(--color-primary)]/10 bg-white shadow-sm md:min-w-[400px]"
          >
            <div className="h-64 w-full overflow-hidden bg-[var(--color-surface)]">
              <img
                src={item.image}
                alt={item.title}
                className="h-full w-full object-cover transition-transform duration-700 hover:scale-105"
                loading="lazy"
                draggable={false}
              />
            </div>
            <div className="p-6">
              <h3 className="mb-3 font-serif text-xl font-semibold text-[var(--color-primary)]">{item.title}</h3>
              <p className="text-sm leading-relaxed text-[var(--color-primary)]/70">{item.description}</p>
            </div>
          </motion.article>
        ))}
      </motion.div>
    </div>
  );
}
