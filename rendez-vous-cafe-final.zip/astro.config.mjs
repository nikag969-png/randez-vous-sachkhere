import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
import react from '@astrojs/react';
import sitemap from '@astrojs/sitemap';
import vercel from '@astrojs/vercel';

export default defineConfig({
  site: 'https://rendezvous-sachkhere.ge',
  output: 'server',
  adapter: vercel(),
  integrations: [tailwind(), react(), sitemap()],
  prefetch: {
    prefetchAll: true,
    defaultStrategy: 'viewport'
  }
});
